
import os

from flask import Flask, jsonify, send_from_directory
from backend.api import register_api


FRONTEND_FOLDER = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "frontend")
)


def create_app():
    app = Flask(__name__)

    app.config["JSON_SORT_KEYS"] = False

    register_api(app)

    @app.route("/")
    def home():
        return send_from_directory(
            FRONTEND_FOLDER,
            "index.html"
        )

    @app.route("/<path:filename>")
    def frontend_files(filename):
        return send_from_directory(
            FRONTEND_FOLDER,
            filename
        )

    @app.route("/api/health", methods=["GET"])
    def health():
        return jsonify({
            "project": "ULTRON AI 4.0",
            "status": "online",
            "message": "ULTRON backend is running."
        })

    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
            "error": "Requested route was not found."
        }), 404

    @app.errorhandler(500)
    def server_error(error):
        return jsonify({
            "error": "Internal server error."
        }), 500

    return app
